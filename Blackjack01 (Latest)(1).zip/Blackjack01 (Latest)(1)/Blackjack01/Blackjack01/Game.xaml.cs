﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Image = System.Windows.Controls.Image;

namespace Blackjack01
{
    /// <summary>
    /// Interaction logic for Game.xaml
    /// </summary>
    
    public partial class Game : Window
    {
        public static int onTop;
        String[] suits = new String[] {"H","D","C","S"};
        String[] numbers = new string[] { "A","2", "3", "4", "5", "6", "7","8","9","10","J","Q","K"};
        public Card[] Deck = new Card[52];
        int moneypool = 1000;
        Hand[] hands = new Hand[4];
        int currenthand = 0;
        int Deck_Marker = 51;
        Hand DealerH;
        public Game()
        {
            InitializeComponent();
            //Create the deck and position it
            int index = 0;
            for (int s = 0; s < suits.Length; s++) {
                for (int n = 0; n < numbers.Length; n++)
                {
                    Card a = new Card(numbers[n] + suits[s]);
                    Deck[index] = a;
                    this.grd_Game.Children.Add(a.CardPic);
                    a.CardPic.Height = 100;
                    a.CardPic.Width = 100;
                    a.CardPic.Margin = new Thickness(70 + index/2, 0,0,0);
                    index += 1;
                }
            }
            //Shuffle
            Shuffle();
            btn_Hit.Visibility = Visibility.Hidden;
            btn_Stay.Visibility = Visibility.Hidden;
            btn_Split.Visibility = Visibility.Hidden;
            btn_DblDown.Visibility = Visibility.Hidden;
        }
        private void Shuffle() {
            Random r = new Random();
            LinkedList<Card> a = new LinkedList<Card>();
            for (int i = 0; i < Deck.Length; i++) {
                a.AddLast(Deck[i]);
                Deck[i].Conceal();
            }
            Card[] temp = new Card[52];
            int index = 0;
            while (a.Any()) {
                int x = (int)(r.NextDouble() * a.Count());
                temp[index] = a.ElementAt(x);
                a.Remove(a.ElementAt(x));
                index += 1;
            }
            Deck = temp;
            for (int i = 0; i < Deck.Length; i++) {
                Deck[i].CardPic.Margin = new Thickness(70 + i/2, 0, 0, 0);
                Deck[i].CardPic.SetValue(Canvas.ZIndexProperty, Game.onTop);
                Game.onTop++;
            }
            Deck_Marker = 51;
        }
        private void btn_Hit_Click(object sender, RoutedEventArgs e)
        {
            btn_DblDown.Visibility = Visibility.Hidden;
            btn_Split.Visibility = Visibility.Hidden;
            dealCard(hands[currenthand], true);
            CheckAces(hands[currenthand]);
            if (PlayerBust(hands[currenthand])) { Stay(null, null); }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void Deal(object sender, RoutedEventArgs e) {
            btn_Deal.Visibility = Visibility.Hidden;
            hands[currenthand] = new Hand(currenthand);
            DealerH = new Hand(-1);
            dealCard(DealerH, false);
            dealCard(DealerH, true);
            dealCard(hands[currenthand], true);
            dealCard(hands[currenthand], true);
            btn_Hit.Visibility = Visibility.Visible;
            btn_Stay.Visibility = Visibility.Visible;
            btn_DblDown.Visibility = Visibility.Visible;
            //Determine if split available
            Card[] pair = hands[currenthand].cards.ToArray();
            if (pair[0].value == pair[1].value || pair[0].name().Substring(0, 1).Equals(pair[1].name().Substring(0, 1))) {
                //first condition is same value, second is a pair
                btn_Split.Visibility = Visibility.Visible;
            }
            //Check for blackjack//
        }
        private void Stay(object sender, RoutedEventArgs e)
        {

            if (hands[currenthand + 1] == null)
            {
                //shutdown all buttons
                btn_Stay.Visibility = Visibility.Hidden;
                btn_DblDown.Visibility = Visibility.Hidden;
                btn_Split.Visibility = Visibility.Hidden;
                btn_Hit.Visibility = Visibility.Hidden;
                DealerTurn();
            }
            else
            {
                currenthand += 1;
                btn_Hit_Click(null, null);
                btn_DblDown.Visibility = Visibility.Visible;
                Card[] pair = hands[currenthand].cards.ToArray();
                if (pair[0].value == pair[1].value || pair[0].name().Substring(0, 1).Equals(pair[1].name().Substring(0, 1)))
                {
                    //first condition is same value, second is a pair
                    btn_Split.Visibility = Visibility.Visible;
                }
                //start from where bets were just placed for this hand
            }
        }

        private void DblDown(object sender, RoutedEventArgs e)
        {
            //hands[currenthand].bet = hands[currenthand].bet * 2;
            btn_Hit_Click(null, null);
            CheckAces(hands[currenthand]);
            Stay(null, null);
        }
        private void Split(object sender, RoutedEventArgs e)
        {
            Card c = hands[currenthand].cards.Last();
            hands[currenthand].cards.Remove(c);
            hands[currenthand + 1] = new Hand(currenthand + 1);
            hands[currenthand + 1].AddCard(c);
            btn_Hit_Click(null, null);
            Card[] pair = hands[currenthand].cards.ToArray();
            if (pair[0].value == pair[1].value || pair[0].name().Substring(0, 1).Equals(pair[1].name().Substring(0, 1)))
            {
                //first condition is same value, second is a pair
                btn_Split.Visibility = Visibility.Visible;
            }
            else {
                btn_Split.Visibility = Visibility.Hidden;
            }
        }
        private void DealerTurn()
        {
            //code for reveal hand
            DealerH.cards.ElementAt(0).Reveal();
            bool allbust = true;
            for (int i = 0; i < hands.Length; i++) {
                if (hands[i] != null && !PlayerBust(hands[i]))
                {
                    allbust = false;
                }
                
            }
            if (allbust) return;
            //code of Algorithm of dealer's turn
            while (DealerH.handvalue() < 17 || (DealerH.handvalue() == 17 && DealerH.getAces().Length != 0)) {
                if (DealerH.handvalue() < 17)
                {
                    //hit on dealer
                    dealCard(DealerH, true);
                    CheckAces(DealerH);
                }
                else if (DealerH.handvalue() == 17 && DealerH.getAces().Length != 0)
                {
                    Card[] aces = DealerH.getAces();
                    for (int i = 0; i < aces.Length; i++) {
                        if (aces[i].value == 11) {
                            //hit on dealer
                            dealCard(DealerH, true);
                            CheckAces(DealerH);
                        }
                    }
                }
                else
                {
                    //stay
                }
            }
            ///////////////////////////////////
            for (int i = 0; i < hands.Length; i++)
            {
                if (hands[i] != null)
                {
                    if (hands[i].handvalue() > 21)
                    {
                        //moneypool -= hands[currenthand].bet;
                        Console.WriteLine("Player busted");
                    }
                    else if (DealerH.handvalue() > 21)
                    {
                        //moneypool += hands[currenthand].bet
                        Console.WriteLine("Dealer Busts, Player Wins!");
                    }
                    else if (DealerH.handvalue() > hands[i].handvalue())
                    {
                        //moneypool -= hands[currenthand].bet;
                        Console.WriteLine("Player Loses!");
                    }
                    else if (DealerH.handvalue() < hands[i].handvalue())
                    {
                        //moneypool += hands[currenthand].bet;
                        Console.WriteLine("Player Wins!");
                    }
                }
            }
        }
        private void dealCard(Hand hand, bool faceUP)
        {
            //
            hand.AddCard(Deck[Deck_Marker]);
            if (faceUP)
            {
                Deck[Deck_Marker].Reveal();
            }
            else {
                Deck[Deck_Marker].Conceal();
            }
            Deck_Marker--;
        }
        private void Reset(object sender, RoutedEventArgs e)
        {
            btn_Hit.Visibility = Visibility.Hidden;
            btn_Stay.Visibility = Visibility.Hidden;
            btn_Split.Visibility = Visibility.Hidden;
            btn_DblDown.Visibility = Visibility.Hidden;
            btn_Deal.Visibility = Visibility.Visible;
            currenthand = 0;
            for (int i = 0; i < hands.Length; i++) {
                hands[i] = null;
            }
            for (int i = Deck_Marker; i < Deck.Length; i++) {
                Deck[i].CardPic.Margin = new Thickness(370 - (i - Deck_Marker) / 2, 0, 0, 0);
            }
            if (Deck_Marker < 12) {
                Shuffle();
            }
        }

        private bool PlayerBust(Hand hand)
        {
            CheckAces(hand);
            if (hands[currenthand].handvalue() > 21)
            {
                //Stay(null, null);
                return true;
            }
            else if (hands[currenthand].handvalue() == 21)
            {
                //Stay(null, null);
                return false;
            }
            else
            {
                return false;
            }

        }
        private void CheckAces(Hand hand)
        {
            if (hand.handvalue() > 21)
            {
                Card[] aces = hand.getAces();
                for (int i = 0; i < aces.Length; i++)
                {
                    if (aces[i].value == 11)
                    {
                        aces[i].value = 1;
                        break;
                    }
                }
            }
        }

        private void btn_Quit_Click(object sender, RoutedEventArgs e)
        {
            //Close this window
            this.Close();
        }
    }
}
