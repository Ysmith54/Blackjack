﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Image = System.Windows.Controls.Image;

namespace Blackjack01
{
    public class Card
    {
        String cardName;
        public int value;
        public Image CardPic = new Image();
        ImageSource BackSide;
        ImageSource FrontSide;
        public Card(String theCard)
        {
            this.cardName = theCard;
            this.FrontSide = new BitmapImage(new Uri(@"pack://application:,,,/Resources/" + this.cardName + ".png", UriKind.RelativeOrAbsolute));
            this.BackSide = new BitmapImage(new Uri(@"pack://application:,,,/Resources/purple_back.png", UriKind.RelativeOrAbsolute));
            this.CardPic.Source = this.BackSide;
            this.CardPic.Visibility = Visibility.Visible;

            if (cardName.Contains("A"))
            {
                this.value = 11;
            }
            else if (cardName.Contains("J") || cardName.Contains("Q") || cardName.Contains("K"))
            {
                this.value = 10;
            }
            else {
                this.value = int.Parse(cardName.Substring(0, cardName.Length - 1));
            }
        }
        public String name()
        {
            return this.cardName;
        }
        public void Reveal()
        {
            this.CardPic.Source = this.FrontSide;
        }
        public void Conceal() {
            this.CardPic.Source = this.BackSide;
        }
    }
}
