﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Blackjack01
{
    public class Hand
    {
        Card[] temp;
        public LinkedList<Card> cards = new LinkedList<Card>();
        private int hand_number;
        public Hand(int num)
        {
            this.hand_number = num;
        }
        public int handvalue()
        {
            //algorithm to calculate hand
            int value = 0;
            temp = cards.ToArray();
            for (int i = 0; i < temp.Length; i++) {
                value += temp[i].value;
            }
            return value;
        }
        public Card[] getAces()
        {
            //algorithim to find all aces and return an array
            LinkedList<Card> tempp = new LinkedList<Card>();
            temp = cards.ToArray();
            for (int i = 0; i < temp.Length; i++) {
                if (temp[i].name().Contains("A")) {
                    tempp.AddLast(temp[i]);
                }
            }
            return tempp.ToArray();
        }
        public void AddCard(Card c) {
            cards.AddLast(c);
            if (hand_number == -1)
            {
                //Dealer Hand
                c.CardPic.Margin = new System.Windows.Thickness(-800 + cards.Count() * 35, -300, 0, 0);
            }
            else {
                c.CardPic.Margin = new System.Windows.Thickness(400 * hand_number + cards.Count() * 35 - 800,300, 0, 0);
            }
            c.CardPic.SetValue(Canvas.ZIndexProperty, Game.onTop);
            Game.onTop++;
        }
    }
}
